import React from 'react';
import { Bot, User } from 'lucide-react';
import { cn } from '../lib/utils';
import ReactMarkdown from 'react-markdown';

interface ChatMessageProps {
  message: string;
  isBot: boolean;
  source?: string;
}

export function ChatMessage({ message, isBot, source }: ChatMessageProps) {
  return (
    <div
      className={cn(
        "flex gap-4 p-6 rounded-xl transition-all",
        isBot ? "bg-white shadow-lg" : "bg-blue-50"
      )}
    >
      <div className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
        isBot ? "bg-emerald-100 text-emerald-600" : "bg-blue-100 text-blue-600"
      )}>
        {isBot ? <Bot size={24} /> : <User size={24} />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="prose prose-slate max-w-none">
          <ReactMarkdown>{message}</ReactMarkdown>
        </div>
        {source && (
          <p className="mt-3 text-sm text-gray-500 border-t border-gray-100 pt-3">
            출처: {source}
          </p>
        )}
      </div>
    </div>
  );
}