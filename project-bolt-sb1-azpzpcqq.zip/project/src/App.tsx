import React, { useState } from 'react';
import { Book, Scroll } from 'lucide-react';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { searchDonguiBogam } from './data/dongui-bogam';
import { queryGemini } from './lib/gemini';

interface Message {
  text: string;
  isBot: boolean;
  source?: string;
}

const MEDICAL_DISCLAIMER = "제공되는 정보는 교육 목적으로만 사용되며 의학적 조언으로 간주되어서는 안 됩니다. 건강상의 문제는 반드시 전문 의료인과 상담하시기 바랍니다.";

function App() {
  const [messages, setMessages] = useState<Message[]>([
    { text: MEDICAL_DISCLAIMER, isBot: true },
    { text: "안녕하세요! 동의보감 도우미입니다. 어떤 도움이 필요하신가요?", isBot: true }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (message: string) => {
    setIsLoading(true);
    setMessages(prev => [...prev, { text: message, isBot: false }]);

    try {
      const geminiResponse = await queryGemini(message);
      setMessages(prev => [...prev, {
        text: geminiResponse,
        isBot: true,
        source: "동의보감 기반 AI 답변"
      }]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        text: "죄송합니다. 답변을 생성하는 중 오류가 발생했습니다. 다시 시도해 주세요.",
        isBot: true 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <header className="bg-white border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-100 p-2 rounded-lg">
              <Scroll className="text-emerald-600" size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">동의보감</h1>
              <p className="text-sm text-gray-500 mt-0.5">한의학 지식 도우미</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        <div className="space-y-6 mb-6">
          {messages.map((message, index) => (
            <ChatMessage
              key={index}
              message={message.text}
              isBot={message.isBot}
              source={message.source}
            />
          ))}
        </div>

        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-5xl px-6">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100">
            <ChatInput onSend={handleSendMessage} disabled={isLoading} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;