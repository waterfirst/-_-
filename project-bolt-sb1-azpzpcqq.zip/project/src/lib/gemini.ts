import { GoogleGenerativeAI } from '@google/generative-ai';
import { getDonguiBogamContext } from '../data/dongui-bogam';

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);

export async function queryGemini(question: string): Promise<string> {
  const donguiBogamContext = getDonguiBogamContext();
  
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    
    const prompt = `당신은 한의학과 동의보감에 대해 잘 알고 있는 전문가입니다. 
다음은 동의보감의 주요 내용입니다:

${donguiBogamContext}

위의 동의보감 내용을 기반으로 다음 질문에 답변해주세요:
${question}

다음 지침을 따라주세요:
1. 동의보감의 원문 내용을 최대한 활용하여 답변하세요.
2. 답변할 때는 현대적인 관점에서 이해하기 쉽게 설명해주세요.
3. 의학적 용어나 한자어가 나올 경우, 가능한 한글로 풀어서 설명해주세요.
4. 마크다운 문법을 사용하여 답변을 구조화하세요:
   - 제목은 # 또는 ## 사용
   - 중요한 내용은 **강조**
   - 목록이 필요한 경우 - 또는 1. 사용
   - 인용이 필요한 경우 > 사용
5. 답변 마지막에는 항상 "이는 참고용 정보이며, 실제 치료는 전문 한의사와 상담하시기 바랍니다."라는 문구를 포함해주세요.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Gemini API 오류:', error);
    throw new Error('답변을 생성하는 중 오류가 발생했습니다.');
  }
}