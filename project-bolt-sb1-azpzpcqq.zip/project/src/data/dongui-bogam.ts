// 동의보감 데이터
export const donguiBogamData = [
  {
    chapter: "내경편",
    sections: [
      {
        title: "신형(身形)",
        content: `사람은 천지의 기운을 받아서 생기고 사계절의 법칙에 따라 자란다. 
하늘은 둥글고 땅은 네모진데, 사람의 머리는 둥글고 발은 네모지니 하늘과 땅을 본뜬 것이다.
사람의 오장은 오행을 본받았으니, 간은 목이요, 심은 화요, 비는 토요, 폐는 금이요, 신은 수이다.
사람의 오장육부는 모두 기를 위주로 하니, 기는 혈의 주가 되고 혈은 기의 배필이 된다.`
      },
      {
        title: "정(精)",
        content: `정이란 것은 생명의 근원이요, 신의 바탕이다.
정이 충실하면 기가 튼튼하고, 정이 허하면 기가 쇠한다.
정은 수에 속하고 심에 매어 있으니, 그러므로 마음을 평온하게 하고 욕심을 줄이면 정이 저절로 충실해진다.`
      }
    ]
  },
  {
    chapter: "외형편",
    sections: [
      {
        title: "두(頭)",
        content: `머리는 정신이 모이는 곳이요, 모든 양기가 모이는 곳이다.
뇌수는 원기의 바다이며, 정미로운 기운이 모이는 곳이다.
머리는 모든 양맥이 모이는 곳이니 청양지회(淸陽之會)라 한다.`
      },
      {
        title: "면(面)",
        content: `얼굴은 오장의 정기가 모이는 곳이다.
오장의 기가 얼굴에 나타나니, 얼굴빛을 보면 오장의 상태를 알 수 있다.
간은 눈에 통하고, 심은 혀에 통하며, 비는 입에 통하고, 폐는 코에 통하며, 신은 귀에 통한다.`
      }
    ]
  },
  {
    chapter: "잡병편",
    sections: [
      {
        title: "풍(風)",
        content: `풍은 백병의 으뜸이니, 풍이 성하면 온갖 병이 생긴다.
풍은 양에 속하여 위로 떠서 머리에 모이기를 좋아한다.
풍한(風寒)이 몸에 들어오면 처음에는 머리가 아프고 몸이 떨리며 열이 나고 땀이 나지 않는다.`
      },
      {
        title: "한(寒)",
        content: `한사는 양기를 손상시키고 혈맥을 수축시킨다.
한사가 피부로 들어오면 모공이 닫히고 땀이 나지 않으며,
한사가 장부에 들어가면 배가 아프고 설사를 한다.`
      }
    ]
  }
];

export function searchDonguiBogam(query: string): { text: string; source: string; chapter: string; title: string } | null {
  const normalizedQuery = query.toLowerCase();
  
  for (const chapter of donguiBogamData) {
    for (const section of chapter.sections) {
      if (
        section.title.toLowerCase().includes(normalizedQuery) ||
        section.content.toLowerCase().includes(normalizedQuery)
      ) {
        return {
          text: section.content,
          source: `동의보감 ${chapter.chapter}`,
          chapter: chapter.chapter,
          title: section.title
        };
      }
    }
  }
  
  return null;
}

export function getDonguiBogamContext(): string {
  return donguiBogamData.map(chapter => 
    `${chapter.chapter}:\n${chapter.sections.map(section =>
      `${section.title}\n${section.content}`
    ).join('\n\n')}`
  ).join('\n\n');
}